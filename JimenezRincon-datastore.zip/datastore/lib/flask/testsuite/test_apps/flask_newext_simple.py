ext_id = 'newext_simple'
